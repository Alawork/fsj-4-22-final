package com.example.springsecurityapplication.enumm;

public enum Status {

    Принят, Оформлен, Ожидает, Получен
}
